#!/usr/bin/env bash
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Instale Node.js 20+"; exit 1; }
node server.mjs
