# Mundo Digital — pacote pronto para executar

## O que já está ligado
- Firebase Authentication
- Firestore para utilizadores, conversas, grupos e sinalização das chamadas
- Firebase Storage para fotos de perfil, fotos de grupos e áudios
- WebRTC para chamadas de voz/vídeo em tempo real
- STUN para ajudar a estabelecer conexões pela Internet
- Perfil editável: nome, bio, telefone e foto
- Criação de grupos e conversa em tempo real

## Executar no computador
Requer Node.js 20+.

### Windows
Abra `start.bat` ou execute:
`node server.mjs`

### Linux/macOS
Execute:
`./start.sh`

Depois abra `http://localhost:8080`.

Não abra o HTML diretamente com `file://`, porque APIs de câmera/microfone e módulos web funcionam melhor através de HTTP/HTTPS.

## Colocar online
Para chamadas entre telemóveis/computadores pela Internet, publique o conteúdo em HTTPS. Como o projeto já aponta para o Firebase `mundo-digital-9429d`, a opção simples é Firebase Hosting:

1. Instale o Firebase CLI.
2. Faça `firebase login`.
3. Dentro desta pasta execute `firebase deploy --only hosting,firestore:rules,storage`.

O navegador deve abrir o site em HTTPS para permitir câmera/microfone fora do localhost.

## TURN para redes difíceis
O código já usa vários servidores STUN públicos. STUN não garante conectividade em todas as redes. Para qualidade de produção, adicione um servidor TURN (por exemplo, coturn ou um serviço TURN) ao `rtcConfig` do `index.html`. Nunca coloque uma credencial TURN permanente no código público; prefira credenciais temporárias.

## Segurança
As regras incluídas são uma base funcional. Antes de produção, ajuste as regras de `chats`, `contents` e `storage` de acordo com a sua política de privacidade e permissões.
