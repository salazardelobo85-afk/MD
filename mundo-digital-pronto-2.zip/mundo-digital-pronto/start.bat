@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Instale Node.js 20+ e tente novamente.&pause&exit /b 1)
node server.mjs
